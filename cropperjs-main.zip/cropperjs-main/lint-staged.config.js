module.exports = {
  '*.js': 'eslint --fix',
  '*.{css,scss}': 'stylelint --fix',
};
